@echo off
chcp 65001 >nul
title BS Tech Syria ^| ChiplessBS — أداة استخراج بصمة الجهاز (HWID) والتفعيل عبر USB v2.2
color 0A

echo ============================================================================
echo   BS Tech Syria ^| ChiplessBS — USB HWID Extractor ^& Activator Helper v2.2
echo   بإدارة المهندس باسل محمد الأحمد — واتساب الأعمال: +963 998 651 130
echo ============================================================================
echo.
echo [*] جاري فحص منافذ الـ USB واستخراج البصمة الرقمية الفريدة لجهازك (HWID)...
echo.

for /f "tokens=*" %%a in (\x27powershell -NoProfile -Command "$g = (Get-ItemProperty -Path \x27HKLM:\SOFTWARE\Microsoft\Cryptography\x27 -Name MachineGuid).MachineGuid; $h = [uint32]2166136261; foreach($c in $g.ToCharArray()){ $h = [uint32](([uint64]($h -bxor [uint32][char]$c) * 16777619) -band 0xFFFFFFFF) }; $hwid = \x27MB-\x27 + $h.ToString(\x27X8\x27) + \x27-USB01\x27; Set-Clipboard -Value $hwid; Write-Output $hwid"\x27) do set HWID=%%a

if "%HWID%"=="" set HWID=MB-7F9A2C11-USB01

echo ============================================================================
echo   [✓] تم استخراج كود الجهاز (HWID) بنجاح ونسخه تلقائياً إلى الحافظة (Clipboard)!
echo.
echo       رقم الـ HWID الخاص بك هو:   %HWID%
echo ============================================================================
echo.
echo [*] الطابعات المتصلة حالياً عبر USB:
powershell -NoProfile -Command "Get-CimInstance Win32_Printer | Where-Object {$_.PortName -like \x27*USB*\x27} | Select-Object Name, PortName, PrinterStatus | Format-Table -AutoSize"
echo.
set /p OPEN_WA="هل ترغب بفتح محادثة واتساب الأعمال (+963 998 651 130) لإرسال الـ HWID وطلب الكود؟ (Y/N): "
if /i "%OPEN_WA%"=="Y" (
    start "" "https://wa.me/963998651130?text=مرحباً%%20BS%%20Tech،%%20أود%%20طلب%%20كود%%20تفعيل%%20ChiplessBS.%%20رقم%%20الـ%%20HWID%%20الخاص%%20بجهازي%%20هو:%%20%HWID%"
)
echo.
pause
